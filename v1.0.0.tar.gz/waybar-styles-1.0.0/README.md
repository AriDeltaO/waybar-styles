# Waybar Styles

This repository contains multiple themes for customizing your Waybar status bar. It includes themes like dark, light, minimal, and modern.

## Installation

To install and use these themes, you can follow the steps below or install the AUR package (once it's live):

### Manual Installation:
1. Clone this repository:
   ```bash
   git clone https://github.com/yourusername/waybar-styles.git

